# Surge XT for WebCLAP

Surge XT by the Surge Synth Team, a hybrid synthesizer, ported to WebCLAP. This is not an official Surge XT release.
Lua (formula modulation, wavetable scripts), MTS-ESP and OSC are not part of this build.

**This is a modified version of Surge XT** (changes made 2026-10-10, in `patches/surge-*.patch` of the port's
source): it has no undo history of its own (the host's history covers the plugin), loads patches without a thread,
and leaves out the parts named above.

- Surge XT: https://github.com/surge-synthesizer/surge (commit 4f425b0, version 1.4.0)
- This port, and the complete source of this bundle: https://github.com/andremichelle/juce-webclap-plugins/tree/ecab895191bf7dc4632dd0ef3a78fe468cd4116f
  Build it with `scripts/build-surge-xt.sh`, which fetches every dependency below at the commit named here and
  applies the changes in `patches/surge-*.patch`.

## License

The bundle as a whole is licensed under the **GNU Affero General Public License, version 3** (`LICENSE`).

Surge XT is GPL-3.0-or-later (`licenses/GPL-3.0.txt`), except its fonts. Both modules contain the JUCE framework,
used under the AGPL-3.0, so `module.wasm` and `ui/ui.wasm` are AGPL-3.0. GPL-3.0 section 13 permits the combination.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the licenses for details.

## Components

| Component | In | Copyright | License |
|---|---|---|---|
| [Surge XT](https://github.com/surge-synthesizer/surge), incl. its factory patches, wavetables and skins | both | 2004-2018 Vember Audio, Claes Johanson; since 2018 various authors | GPL-3.0-or-later |
| [sst-basic-blocks, sst-cpputils, sst-effects, sst-filters, sst-plugininfra, sst-waveshapers](https://github.com/surge-synthesizer) | both | Surge Synth Team, various authors | GPL-3.0-or-later or MIT, per library |
| WebCLAP port ([juce-webclap-plugins](https://github.com/andremichelle/juce-webclap-plugins)) | both | André Michelle | MIT |
| [JUCE](https://juce.com) | both | Raw Material Software Limited | AGPL-3.0 |
| [Airwindows](https://github.com/airwindows/airwindows) | both | 2018 Chris Johnson | MIT (`licenses/Airwindows.txt`) |
| [Mutable Instruments eurorack](https://github.com/pichenettes/eurorack) (Plaits, Clouds) | both | 2014-2020 Emilie Gillet | MIT |
| [tuning-library](https://github.com/surge-synthesizer/tuning-library) | both | 2019-2020 Paul Walker | MIT (`licenses/tuning-library.md`) |
| [{fmt}](https://github.com/fmtlib/fmt) | both | 2012-present Victor Zverovich | MIT with an exception for binaries (`licenses/fmt.txt`) |
| [PEGTL](https://github.com/taocpp/PEGTL) | both | 2007-2020 Dr. Colin Hirsch and Daniel Frey | MIT (`licenses/PEGTL.txt`) |
| [r8brain-free-src](https://github.com/avaneev/r8brain-free-src) | both | 2013-2023 Aleksey Vaneev | MIT (`licenses/r8brain.txt`) |
| [PFFFT](https://github.com/surge-synthesizer/pffft) | both | 2013 Julien Pommier; 2004 UCAR (FFTPACK) | BSD-like FFTPACK license, see its source |
| [Zstandard](https://github.com/facebook/zstd) | both | Meta Platforms, Inc. and affiliates | BSD-3-Clause (`licenses/zstd.txt`) |
| [binn](https://github.com/liteserver/binn) | both | 2015 Bernardo Ramos | Apache-2.0 (`licenses/binn.txt`) |
| [SQLite](https://sqlite.org) | both | public domain | public domain |
| [ghc::filesystem](https://github.com/gulrak/filesystem) | both | 2018 Steffen Schümann | MIT |
| [SIMDe](https://github.com/simd-everywhere/simde) | both | Evan Nemerson and contributors | MIT |
| [CLAP](https://github.com/free-audio/clap) | module | 2021 Alexandre Bique | MIT |
| Lato font | ui | 2010-2015 Łukasz Dziedzic | SIL Open Font License 1.1 (`licenses/OFL-1.1-Lato.txt`) |
| Fira Mono font | ui | 2012-2015 The Mozilla Foundation and Telefonica S.A. | SIL Open Font License 1.1 |
| Indie Flower font | ui | 2011 Kimberly Geswein | SIL Open Font License 1.1 |
| [DejaVu Sans](https://dejavu-fonts.github.io) font | ui | Bitstream, Tavmjong Bah; DejaVu changes public domain | Bitstream Vera (`licenses/DejaVu.txt`) |

## JUCE's bundled libraries

JUCE contains third-party libraries under their own licenses. Their texts are in `licenses/JUCE-*.txt`.

| Library | Part of JUCE | License |
|---|---|---|
| [zlib](https://zlib.net) | juce_core | zlib (`licenses/JUCE-zlib.txt`) |
| [libpng](http://www.libpng.org) | juce_graphics (editor) | PNG Reference Library License v2 (`licenses/JUCE-libpng.txt`) |
| libjpeg, Independent JPEG Group | juce_graphics (editor) | IJG License (`licenses/JUCE-libjpeg.txt`) |
| [HarfBuzz](https://harfbuzz.github.io) | juce_graphics (editor) | Old MIT (`licenses/JUCE-HarfBuzz.txt`) |
| [SheenBidi](https://github.com/Tehreer/SheenBidi) | juce_graphics (editor) | Apache-2.0 (`licenses/JUCE-SheenBidi-Apache-2.0.txt`) |
| [FLAC](https://xiph.org/flac/) | juce_audio_formats, in bundles that decode FLAC | BSD-3-Clause (`licenses/JUCE-FLAC.txt`) |

This software is based in part on the work of the Independent JPEG Group.

## License texts

### MIT

Applies to the components marked MIT above, each under its own copyright line.

> Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
> documentation files (the "Software"), to deal in the Software without restriction, including without limitation
> the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
> to permit persons to whom the Software is furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in all copies or substantial portions of
> the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
> THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
> CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
> IN THE SOFTWARE.

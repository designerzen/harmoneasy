# RipplerX for WebCLAP

RipplerX by tilr, a physically modeled synth, ported to WebCLAP. This is not an official RipplerX release.

- RipplerX: https://github.com/tiagolr/ripplerx (commit 11683a6, version 1.5.18)
- This port, and the complete source of this bundle: https://github.com/andremichelle/juce-webclap-plugins/tree/ecab895191bf7dc4632dd0ef3a78fe468cd4116f
  Build it with `scripts/build-ripplerx.sh`, which fetches every dependency below at the commit named here.

## License

The bundle as a whole is licensed under the **GNU Affero General Public License, version 3** (`LICENSE`).

RipplerX is GPL-3.0 (`licenses/GPL-3.0.txt`). Both modules contain the JUCE framework, used under the AGPL-3.0, so
`module.wasm` and `ui/ui.wasm` are AGPL-3.0. GPL-3.0 section 13 permits the combination.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the licenses for details.

RipplerX is a port of tilr's Rippler2 JSFX, which builds on Saike's [Partials](https://github.com/JoepVanlier/JSFX)
(MIT) and takes its models after AAS Chromaphone and Collision.

## Components

| Component | In | Copyright | License |
|---|---|---|---|
| [RipplerX](https://github.com/tiagolr/ripplerx), incl. presets, images and mallet samples | both | 2025 tilr | GPL-3.0 |
| Limiter in RipplerX (port of the FairlyChildish limiter JSFX) | both | 2006, Thomas Scott Stillwell | BSD-3-Clause style |
| WebCLAP port ([juce-webclap-plugins](https://github.com/andremichelle/juce-webclap-plugins)) | both | André Michelle | MIT |
| [JUCE](https://juce.com) | both | Raw Material Software Limited | AGPL-3.0 |
| [MTS-ESP client](https://github.com/ODDSound/MTS-ESP) | both | 2021 ODDSound Ltd. | 0BSD |
| [CLAP](https://github.com/free-audio/clap) | module | 2021 Alexandre Bique | MIT |
| Ubuntu Medium font | ui | 2011 Canonical Ltd. | Ubuntu Font Licence 1.0 (`licenses/UFL-1.0-Ubuntu.txt`) |
| [DejaVu Sans](https://dejavu-fonts.github.io) font | ui | Bitstream, Tavmjong Bah; DejaVu changes public domain | Bitstream Vera (`licenses/DejaVu.txt`) |

## JUCE's bundled libraries

JUCE contains third-party libraries under their own licenses. Their texts are in `licenses/JUCE-*.txt`.

| Library | Part of JUCE | License |
|---|---|---|
| [zlib](https://zlib.net) | juce_core | zlib (`licenses/JUCE-zlib.txt`) |
| [libpng](http://www.libpng.org) | juce_graphics (editor) | PNG Reference Library License v2 (`licenses/JUCE-libpng.txt`) |
| libjpeg, Independent JPEG Group | juce_graphics (editor) | IJG License (`licenses/JUCE-libjpeg.txt`) |
| [HarfBuzz](https://harfbuzz.github.io) | juce_graphics (editor) | Old MIT (`licenses/JUCE-HarfBuzz.txt`) |
| [SheenBidi](https://github.com/Tehreer/SheenBidi) | juce_graphics (editor) | Apache-2.0 (`licenses/JUCE-SheenBidi-Apache-2.0.txt`) |
| [FLAC](https://xiph.org/flac/) | juce_audio_formats, in bundles that decode FLAC | BSD-3-Clause (`licenses/JUCE-FLAC.txt`) |

This software is based in part on the work of the Independent JPEG Group.

## License texts

### MIT

Applies to the components marked MIT above, each under its own copyright line.

> Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
> documentation files (the "Software"), to deal in the Software without restriction, including without limitation
> the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
> to permit persons to whom the Software is furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in all copies or substantial portions of
> the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
> THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
> CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
> IN THE SOFTWARE.

### BSD (the limiter)

> Copyright 2006, Thomas Scott Stillwell
> All rights reserved.
>
> Redistribution and use in source and binary forms, with or without modification, are permitted provided that the
> following conditions are met:
>
> Redistributions of source code must retain the above copyright notice, this list of conditions and the following
> disclaimer.
>
> Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
> following disclaimer in the documentation and/or other materials provided with the distribution.
>
> The name of Thomas Scott Stillwell may not be used to endorse or promote products derived from this software
> without specific prior written permission.
>
> THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
> INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
> DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
> SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
> SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
> WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
> USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### 0BSD (MTS-ESP client)

> Copyright (C) 2021 by ODDSound Ltd. info@oddsound.com
>
> Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby
> granted.
>
> THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING
> ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL,
> DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
> WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE
> USE OR PERFORMANCE OF THIS SOFTWARE.

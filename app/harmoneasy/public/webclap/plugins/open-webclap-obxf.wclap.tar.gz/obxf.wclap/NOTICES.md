# OB-Xf for WebCLAP

OB-Xf by the Surge Synth Team, a virtual analog synthesizer continuing OB-Xd, ported to WebCLAP. This is not an
official OB-Xf release.

- OB-Xf: https://github.com/surge-synthesizer/OB-Xf (commit b08ffb6)
- This port, and the complete source of this bundle: https://github.com/andremichelle/juce-webclap-plugins/tree/6cb528be3d105c0de68d360e4193b183e28bb883 (plus uncommitted changes: not a release build)
  Build it with `scripts/build-obxf.sh`, which fetches every dependency below at the commit named here.

## License

The bundle as a whole is licensed under the **GNU Affero General Public License, version 3** (`LICENSE`).

OB-Xf is GPL-3.0-or-later (`licenses/GPL-3.0.txt`). Both modules contain the JUCE framework (the DSP module its
GUI-free part), used under the AGPL-3.0, so `module.wasm` and `ui/ui.wasm` are AGPL-3.0. GPL-3.0 section 13
permits the combination.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the licenses for details.

## Components

| Component | In | Copyright | License |
|---|---|---|---|
| [OB-Xf](https://github.com/surge-synthesizer/OB-Xf), incl. factory patches, themes and the Trek font | both | 2013-2025 the authors of OB-Xd (Vadim Filatov, 2DaT, discoDSP) and of OB-Xf per its git log | GPL-3.0-or-later |
| WebCLAP port ([juce-webclap-plugins](https://github.com/andremichelle/juce-webclap-plugins)) | both | André Michelle | MIT |
| [JUCE](https://juce.com) | both | Raw Material Software Limited | AGPL-3.0 |
| [sst-basic-blocks](https://github.com/surge-synthesizer/sst-basic-blocks) | both | Surge Synth Team | GPL-3.0 |
| [sst-cpputils](https://github.com/surge-synthesizer/sst-cpputils) | both | 2019-2021, authors per the git log | MIT |
| [sst-plugininfra](https://github.com/surge-synthesizer/sst-plugininfra) | both | 2019-2020, Paul Walker | MIT |
| [strnatcmp](https://github.com/sourcefrog/natsort) (in sst-plugininfra) | both | 2000, 2004 Martin Pool | zlib |
| [MTS-ESP client](https://github.com/ODDSound/MTS-ESP) | both | 2021 ODDSound Ltd. | 0BSD |
| [{fmt}](https://github.com/fmtlib/fmt) | both | 2012 - present, Victor Zverovich and {fmt} contributors | MIT |
| [SIMDe](https://github.com/simd-everywhere/simde) | both | 2017 Evan Nemerson | MIT |
| [ghc::filesystem](https://github.com/gulrak/filesystem) | both | 2018, Steffen Schümann | MIT |
| [CLAP](https://github.com/free-audio/clap) | module | 2021 Alexandre Bique | MIT |
| [Jersey 20](https://github.com/scfried/soft-type-jersey) font | ui | 2023 The Soft Type Project Authors | OFL-1.1 (`licenses/OFL-Jersey20.txt`) |
| [DejaVu Sans](https://dejavu-fonts.github.io) font | ui | Bitstream, Tavmjong Bah; DejaVu changes public domain | Bitstream Vera (`licenses/DejaVu.txt`) |

## JUCE's bundled libraries

JUCE contains third-party libraries under their own licenses. Their texts are in `licenses/JUCE-*.txt`.

| Library | Part of JUCE | License |
|---|---|---|
| [zlib](https://zlib.net) | juce_core | zlib (`licenses/JUCE-zlib.txt`) |
| [libpng](http://www.libpng.org) | juce_graphics (editor) | PNG Reference Library License v2 (`licenses/JUCE-libpng.txt`) |
| libjpeg, Independent JPEG Group | juce_graphics (editor) | IJG License (`licenses/JUCE-libjpeg.txt`) |
| [HarfBuzz](https://harfbuzz.github.io) | juce_graphics (editor) | Old MIT (`licenses/JUCE-HarfBuzz.txt`) |
| [SheenBidi](https://github.com/Tehreer/SheenBidi) | juce_graphics (editor) | Apache-2.0 (`licenses/JUCE-SheenBidi-Apache-2.0.txt`) |
| [FLAC](https://xiph.org/flac/) | juce_audio_formats, in bundles that decode FLAC | BSD-3-Clause (`licenses/JUCE-FLAC.txt`) |

This software is based in part on the work of the Independent JPEG Group.

## License texts

### MIT

Applies to the components marked MIT above, each under its own copyright line.

> Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
> documentation files (the "Software"), to deal in the Software without restriction, including without limitation
> the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
> to permit persons to whom the Software is furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in all copies or substantial portions of
> the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
> THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
> CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
> IN THE SOFTWARE.

### zlib (strnatcmp)

> This software is provided 'as-is', without any express or implied warranty. In no event will the authors be held
> liable for any damages arising from the use of this software.
>
> Permission is granted to anyone to use this software for any purpose, including commercial applications, and to
> alter it and redistribute it freely, subject to the following restrictions:
>
> 1. The origin of this software must not be misrepresented; you must not claim that you wrote the original
>    software. If you use this software in a product, an acknowledgment in the product documentation would be
>    appreciated but is not required.
> 2. Altered source versions must be plainly marked as such, and must not be misrepresented as being the original
>    software.
> 3. This notice may not be removed or altered from any source distribution.

### 0BSD (MTS-ESP client)

> Copyright (C) 2021 by ODDSound Ltd. info@oddsound.com
>
> Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby
> granted.
>
> THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING
> ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL,
> DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
> WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE
> USE OR PERFORMANCE OF THIS SOFTWARE.

# Droplets for WebCLAP

Droplets by aquanode, a stochastic water bubble synthesizer after xoxos' Water, ported to WebCLAP. This is not an
official aquanode release.

- Droplets: https://github.com/aquanodemusic/aquanode-plugins/tree/main/synths/droplets (commit 35f0676, version 1.1)
- This port, and the complete source of this bundle: https://github.com/andremichelle/open-webclap/tree/8ccc7ea42de533be9b0d6134ed79dcbc15a1586f
  Build it with `scripts/build-droplets.sh`, which fetches every dependency below at the commit named here.

Changes in this port (`patches/droplets-headless.patch`): the processor builds without its editor for the DSP
module. The editor's Arial labels are drawn in DejaVu Sans.

## License

The bundle as a whole is licensed under the **GNU Affero General Public License, version 3** (`LICENSE`).

Droplets is AGPL-3.0 (`licenses/AGPL-3.0.txt`). Both modules contain the JUCE framework, used under the AGPL-3.0.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the licenses for details.

## Components

| Component | In | Copyright | License |
|---|---|---|---|
| [Droplets](https://github.com/aquanodemusic/aquanode-plugins/tree/main/synths/droplets) | both | aquanode | AGPL-3.0 |
| WebCLAP kit ([open-webclap](https://github.com/andremichelle/open-webclap) `modules/juce_webclap`) | both | André Michelle | MIT |
| WebCLAP port ([open-webclap](https://github.com/andremichelle/open-webclap) `ports/droplets`) | both | André Michelle | AGPL-3.0 |
| [JUCE](https://juce.com) | both | Raw Material Software Limited | AGPL-3.0 |
| [CLAP](https://github.com/free-audio/clap) | module | 2021 Alexandre Bique | MIT |
| [DejaVu Sans](https://dejavu-fonts.github.io) font | ui | Bitstream, Tavmjong Bah; DejaVu changes public domain | Bitstream Vera (`licenses/DejaVu.txt`) |

## JUCE's bundled libraries

JUCE contains third-party libraries under their own licenses. Their texts are in `licenses/JUCE-*.txt`.

| Library | Part of JUCE | License |
|---|---|---|
| [zlib](https://zlib.net) | juce_core | zlib (`licenses/JUCE-zlib.txt`) |
| [libpng](http://www.libpng.org) | juce_graphics (editor) | PNG Reference Library License v2 (`licenses/JUCE-libpng.txt`) |
| libjpeg, Independent JPEG Group | juce_graphics (editor) | IJG License (`licenses/JUCE-libjpeg.txt`) |
| [HarfBuzz](https://harfbuzz.github.io) | juce_graphics (editor) | Old MIT (`licenses/JUCE-HarfBuzz.txt`) |
| [SheenBidi](https://github.com/Tehreer/SheenBidi) | juce_graphics (editor) | Apache-2.0 (`licenses/JUCE-SheenBidi-Apache-2.0.txt`) |
| [FLAC](https://xiph.org/flac/) | juce_audio_formats, in bundles that decode FLAC | BSD-3-Clause (`licenses/JUCE-FLAC.txt`) |

This software is based in part on the work of the Independent JPEG Group.

## License texts

### MIT

Applies to the components marked MIT above, each under its own copyright line.

> Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
> documentation files (the "Software"), to deal in the Software without restriction, including without limitation
> the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and
> to permit persons to whom the Software is furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be included in all copies or substantial portions of
> the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
> THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
> AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
> CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
> IN THE SOFTWARE.
